/*
<script src="http://code.jquery.com/jquery-latest.min.js"></script>
jQuery('#region').change(function(){
    var state = jQuery('#region option:selected').val();
    if(state =='1'){
        jQuery('.layer1').show();
        jQuery('.layer2').hide();
        jQuery('.layer3').hide();
        jQuery('.layer4').hide();
        jQuery('.layer5').hide();
        jQuery('.layer6').hide();
        jQuery('.layer7').hide();
        jQuery('.layer8').hide();
        jQuery('.layer9').hide();
    }else if(state =='2'){
        jQuery('.layer1').hide();
        jQuery('.layer2').show();
        jQuery('.layer3').hide();
        jQuery('.layer4').hide();
        jQuery('.layer5').hide();
        jQuery('.layer6').hide();
        jQuery('.layer7').hide();
        jQuery('.layer8').hide();
        jQuery('.layer9').hide();
    }else if(state == '3'){
        jQuery('.layer1').hide();
        jQuery('.layer2').hide();
        jQuery('.layer3').show();
        jQuery('.layer4').hide();
        jQuery('.layer5').hide();
        jQuery('.layer6').hide();
        jQuery('.layer7').hide();
        jQuery('.layer8').hide();
        jQuery('.layer9').hide();
    }else if(state =='4'){
        jQuery('.layer1').hide();
        jQuery('.layer2').hide();
        jQuery('.layer3').hide();
        jQuery('.layer4').show();
        jQuery('.layer5').hide();
        jQuery('.layer6').hide();
        jQuery('.layer7').hide();
        jQuery('.layer8').hide();
        jQuery('.layer9').hide();
    }else if(state =='5'){
        jQuery('.layer1').hide();
        jQuery('.layer2').hide();
        jQuery('.layer3').hide();
        jQuery('.layer4').hide();
        jQuery('.layer5').show();
        jQuery('.layer6').hide();
        jQuery('.layer7').hide();
        jQuery('.layer8').hide();
        jQuery('.layer9').hide();
    }else if(state == '6'){
        jQuery('.layer1').hide();
        jQuery('.layer2').hide();
        jQuery('.layer3').hide();
        jQuery('.layer4').hide();
        jQuery('.layer5').hide();
        jQuery('.layer6').show();
        jQuery('.layer7').hide();
        jQuery('.layer8').hide();
        jQuery('.layer9').hide();
    }else if(state =='7'){
        jQuery('.layer1').hide();
        jQuery('.layer2').hide();
        jQuery('.layer3').hide();
        jQuery('.layer4').hide();
        jQuery('.layer5').hide();
        jQuery('.layer6').hide();
        jQuery('.layer7').show();
        jQuery('.layer8').hide();
        jQuery('.layer9').hide();
    }else if(state =='8'){
        jQuery('.layer1').hide();
        jQuery('.layer2').hide();
        jQuery('.layer3').hide();
        jQuery('.layer4').hide();
        jQuery('.layer5').hide();
        jQuery('.layer6').hide();
        jQuery('.layer7').hide();
        jQuery('.layer8').show();
        jQuery('.layer9').hide();
    }else if(state == '9'){
        jQuery('.layer1').hide();
        jQuery('.layer2').hide();
        jQuery('.layer3').hide();
        jQuery('.layer4').hide();
        jQuery('.layer5').hide();
        jQuery('.layer6').hide();
        jQuery('.layer7').hide();
        jQuery('.layer8').hide();
        jQuery('.layer9').show();
    }
});

$(function(){
    var idval = $('#result-name');
    $('#movie').change(function(){
        var element = $(this).find('option:selected');
        var myTag = element.text();
        // var myTag = element.attr('value');
        idval.val(myTag);
    });
});
$(function(){
    var idval = $('#result-region');
    $('#region').change(function(){
        var element = $(this).find('option:selected');
        var myTag = element.text();
        // var myTag = element.attr('value');
        idval.val(myTag);
    });
});

$(function(){
    var idval = $('#result-theater');
    $('#regionTheater1').change(function(){
        var element = $(this).find('option:selected');
        var myTag = element.text();
        // var myTag = element.attr('value');
        idval.val(myTag);
    });
});
$(function(){
    var idval = $('#result-theater');
    $('#regionTheater2').change(function(){
        var element = $(this).find('option:selected');
        var myTag = element.text();
        // var myTag = element.attr('value');
        idval.val(myTag);
    });
});
$(function(){
    var idval = $('#result-theater');
    $('#regionTheater3').change(function(){
        var element = $(this).find('option:selected');
        var myTag = element.text();
        // var myTag = element.attr('value');
        idval.val(myTag);
    });
});
$(function(){
    var idval = $('#result-theater');
    $('#regionTheater4').change(function(){
        var element = $(this).find('option:selected');
        var myTag = element.text();
        // var myTag = element.attr('value');
        idval.val(myTag);
    });
});
$(function(){
    var idval = $('#result-theater');
    $('#regionTheater5').change(function(){
        var element = $(this).find('option:selected');
        var myTag = element.text();
        // var myTag = element.attr('value');
        idval.val(myTag);
    });
});
$(function(){
    var idval = $('#result-theater');
    $('#regionTheater6').change(function(){
        var element = $(this).find('option:selected');
        var myTag = element.text();
        // var myTag = element.attr('value');
        idval.val(myTag);
    });
});
$(function(){
    var idval = $('#result-theater');
    $('#regionTheater7').change(function(){
        var element = $(this).find('option:selected');
        var myTag = element.text();
        // var myTag = element.attr('value');
        idval.val(myTag);
    });
});
$(function(){
    var idval = $('#result-theater');
    $('#regionTheater8').change(function(){
        var element = $(this).find('option:selected');
        var myTag = element.text();
        // var myTag = element.attr('value');
        idval.val(myTag);
    });
});
$(function(){
    var idval = $('#result-theater');
    $('#regionTheater9').change(function(){
        var element = $(this).find('option:selected');
        var myTag = element.text();
        // var myTag = element.attr('value');
        idval.val(myTag);
    });
});*/