package com.javalec.team.service;

public interface Res_Movie_SeatService {

    //조조 여부 확인





}
