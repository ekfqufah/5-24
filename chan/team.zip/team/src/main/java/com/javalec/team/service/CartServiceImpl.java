package com.javalec.team.service;

import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javalec.team.dao.CartDao;




@Service("CartService")
public class CartServiceImpl implements CartService{
	@Autowired
	private SqlSession sqlSession;

	@Override
	public void insertCart(HashMap<String, String> param) {
		//System.out.println("CartServiceImpl - insertCart");
		CartDao dao = sqlSession.getMapper(CartDao.class);
		
		dao.insertCart(param);
		//System.out.println("CartServiceImpl - insertCart end");
	}
}
