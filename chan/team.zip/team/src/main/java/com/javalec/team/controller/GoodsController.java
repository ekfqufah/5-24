package com.javalec.team.controller;

import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.javalec.team.dto.GoodsDto;
import com.javalec.team.service.CartService;
import com.javalec.team.service.GoodsService;




@Controller
public class GoodsController {
	@Autowired
	private SqlSession sqlSession;
	
	@Autowired
	private GoodsService goodsService;
	
	
	
	public void getGoods(@RequestParam HashMap<String, String> param, Model model) {
		GoodsDto goodsdto = goodsService.getGoods(param);
		int num = 1;
		model.addAttribute("login",num);
		model.addAttribute("goods",goodsdto);
	}
	
	@RequestMapping("/mainview")
	public String mainview() {
		return "mainview";
	}
	
	@RequestMapping("goodsDisplay")
	public String goodsDisplay(@RequestParam HashMap<String, String> param,Model model) {
		getGoods(param,model);
		return "goods/goodsDisplay";
	}
	
	
	
	

}
