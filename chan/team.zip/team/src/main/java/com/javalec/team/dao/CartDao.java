package com.javalec.team.dao;

import java.util.HashMap;

public interface CartDao {
	public void insertCart(HashMap<String, String> param);
}
