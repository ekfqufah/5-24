package com.javalec.team.service;

import java.util.HashMap;

public interface CartService {
	public void insertCart(HashMap<String, String> param);
}
