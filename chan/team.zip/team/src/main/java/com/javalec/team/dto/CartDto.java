package com.javalec.team.dto;

public class CartDto {

}
